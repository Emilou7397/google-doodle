A Pen created at CodePen.io. You can find this one at https://codepen.io/econe/pen/OdGeoY.

 V1 of my Google Doodle with the theme "Tea"